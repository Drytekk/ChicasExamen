<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="Inner" tilewidth="16" tileheight="16" tilecount="1000" columns="40">
 <image source="../Sprites/Inner.png" width="640" height="400"/>
</tileset>
