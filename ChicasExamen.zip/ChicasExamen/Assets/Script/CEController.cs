﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CEController : MonoBehaviour
{
    public GameObject mc;

    void Start()
    {
        
    }

    
    void Update()
    {
        
        
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        //Interaccion del jugador -> Inicio del dialogo modo novela visual
        if (Input.GetKey(KeyCode.F))
        {
            SceneManager.LoadScene("Examen");
        }

        //Canvia el nivel de capa para dar el efecto de estar detras o delante de un npc
        if (mc.transform.position.y > transform.position.y)
        {
            gameObject.GetComponent<SpriteRenderer>().sortingOrder = mc.GetComponent<SpriteRenderer>().sortingOrder + 1;
        }
        else
        {
            gameObject.GetComponent<SpriteRenderer>().sortingOrder = mc.GetComponent<SpriteRenderer>().sortingOrder - 1;
        }
    }
}
